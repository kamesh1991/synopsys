import { Component, OnInit } from '@angular/core';
import { RestService } from './services/rest/rest.service'
import { environment } from '../environments/environment'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(public restService: RestService) { }
  title = 'synopsys-gen-ai';

  ngOnInit(): void {
   //this.getToken();
   //this.refreshToken();
  }
  getToken(): void {
    const tokenData = {
      client_id: environment.client_id,
      client_secret: environment.client_secret,
      grant_type: environment.grant_type
    }
    this.restService.newToken(tokenData).subscribe((data : any) => {
      sessionStorage.setItem( 'encodedAccessToken', data)
    });
  }

  refreshToken(): void {
    const tokenData = {
      client_id: environment.client_id,
      client_secret: environment.client_secret,
      grant_type: 'refresh_token'
    }
    this.restService.newToken(tokenData).subscribe((data : any) => {
      // sessionStorage.setItem( 'encodedAccessToken', data)
    });
  }
}

