import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RelativeSectionComponent } from './relative-section.component';

describe('RelativeSectionComponent', () => {
  let component: RelativeSectionComponent;
  let fixture: ComponentFixture<RelativeSectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RelativeSectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RelativeSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
