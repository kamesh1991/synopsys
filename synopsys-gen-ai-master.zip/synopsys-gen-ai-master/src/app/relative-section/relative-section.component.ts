import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-relative-section',
  templateUrl: './relative-section.component.html',
  styleUrls: ['./relative-section.component.css']
})
export class RelativeSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
