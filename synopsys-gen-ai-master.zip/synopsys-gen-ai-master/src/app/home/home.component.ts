import { Component, Input, OnInit } from '@angular/core';
import { stringConstant } from '../shared/stringConstant';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [stringConstant]
})
export class HomeComponent implements OnInit {
  placeholder = this.stringConstant.placeholder;
  refinelabel: string = '';
  isRefineQuestion: boolean = false;
  showNewQuestion: boolean = true;
  showResponse: boolean = false;
  showFeedback: boolean = false;
  hideExample: boolean = false;
  showFollowUpQuestion: boolean = false;
  questions: any = [];
  maxlength: any;
  countArray: any = [];
  constructor(public stringConstant: stringConstant) { }

  ngOnInit(): void {
  }

  refinequestion() {
    this.isRefineQuestion = true
    this.placeholder = this.stringConstant.refinePlaceholder
  }

  questionSubmit($event: any) {
    this.showResponse = false;
    this.showFeedback = false;
    this.questions.push({ followUpQuestion: this.showFollowUpQuestion, question: $event.inputQuestion, questionlength: $event.QuestionLength })
    this.showNewQuestion = false;
    this.showFollowUpQuestion = false;
    this.hideExample = true;
    setTimeout(() => {
      this.showResponse = true;
    })
  }

  enableFeedback($event: any) {
    this.showFeedback = $event;
  }

  enableQuestion($event: string) {
    if ($event === "NEW") {
      this.showNewQuestion = true;
      this.showFollowUpQuestion = false;
      this.showResponse = false;
      this.questions = [];
      this.maxlength = 4000
     
    } else {
      this.showNewQuestion = false;
      this.showFollowUpQuestion = true;
      if (this.questions.length <= 1) {
        this.maxlength = this.questions[0].questionlength;
      }
      else {
        this.questions.forEach((count: any) => {
          this.countArray.push(count.questionlength)
        });
        this.maxlength = this.countArray.reduce((acc: any, curr: any) => acc + curr, 0);
      }
    }
    this.showFeedback = false;
  }

}
