import {
	HttpClientModule,
	HttpRequest
} from '@angular/common/http';
import {
	inject,
	TestBed
} from '@angular/core/testing';
import {HttpRequestInterceptor} from './http-request.interceptor';
import {of} from 'rxjs';

describe('HttpRequestInterceptor', () => {

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [HttpClientModule],
			providers: [
				HttpRequestInterceptor
			]
		});
	});

	describe('Tests: ', () => {

		let subject:any;
		beforeEach(inject([HttpRequestInterceptor], (httpRequestInterceptor:any) => {
			subject = httpRequestInterceptor;
		}));

		describe('intercept()', () => {
			it('should add headers to the cloned request', (done) => {

				const httpRequest = new HttpRequest('GET', 'http://www.test.com');

				const next = {
					handle: (request:any) => {
						return of(request);
					}
				};

				spyOn(next, 'handle').and.callThrough();

				subject.intercept(httpRequest, next).subscribe((req:any) => {
					expect(next.handle).toHaveBeenCalled();
					done();
				});
			});

		});
	});
});
