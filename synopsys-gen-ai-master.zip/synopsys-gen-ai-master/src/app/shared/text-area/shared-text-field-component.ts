export class SharedTextField {
    inputQuestion : string = '' ;
    QuestionLength : number = 0 ;
}