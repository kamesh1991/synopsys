import { Component, ElementRef, EventEmitter, Input, OnInit, Output, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { SharedTextField } from './shared-text-field-component';

@Component({
  selector: 'text-area',
  templateUrl: './text-area.component.html',
  styleUrls: ['./text-area.component.css'],
  providers: [SharedTextField]
})

export class TextAreaComponent implements OnInit {
  @Input() placeholder: string = ''
  @Input() isRefineQuestion: any = false
  @Input() maxlengthrefine: any;
  inputQuestion: any;
  @Output() submitClick = new EventEmitter<String>();
  @ViewChild("txtArea") inputElement: ElementRef | any;
  charCount: number = 0;
  showlength: boolean = false;
  reamaningCharCount: number = 0;
  maxlength: any = 4000

  constructor(public sharedTextField: SharedTextField) {
    this.inputQuestion = this.sharedTextField.inputQuestion;
  }

  ngOnInit(): void {
    if (this.maxlengthrefine) {
      this.maxlength = 4000 - this.maxlengthrefine
    }
  }

  submitQuestion(sharedTextField: any) {
    this.sharedTextField.QuestionLength = sharedTextField.inputQuestion.length;
    if (this.sharedTextField.QuestionLength > 0) {
      this.submitClick.emit(sharedTextField);
    }
  }

  enterKeyPressed(sharedTextField: any) {
    this.submitQuestion(sharedTextField);
    this.inputElement.nativeElement.blur();
  }

  keyup(sharedTextField: any) {
    this.charCount = sharedTextField.length;
    if (this.charCount > 3500) {
      this.showlength = true
      this.reamaningCharCount = this.maxlength - this.charCount
    }
    else {
      this.showlength = false
    }

  }

}
