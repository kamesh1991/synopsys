import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  closeResult = '';
  msg: any;
  imageUrl:string = "assets/thumbs-up.svg";
  @Output() public enableQuestion = new EventEmitter();
  constructor(private modalService: NgbModal) { }

  ngOnInit(): void {
  }


  open(content: any) {
    this.modalService.open(content, { centered: true }).result.then(
      (result) => {
        this.closeResult = `Closed with: ${result}`;
      },
      (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      },
    );
    this.msg = '';
    this.imageUrl="assets/thumbs-up.svg"
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  clickEvent() {
    this.imageUrl="assets/colored-thumbsup.svg"
    this.msg = "Great! Thanks for the feedback";
    return this.msg;
  }

  question(value : string) {
    this.enableQuestion.emit(value)
  }

}
