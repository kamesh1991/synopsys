export const ApiEndPoints = {
    tokenUrl : '/token'
}