import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'title-description',
  templateUrl: './title-description.component.html',
  styleUrls: ['./title-description.component.css']
})
export class TitleDescriptionComponent implements OnInit {

  constructor() { }
  @Input() hideExample:any;
  ngOnInit(): void {
  }

}
