import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'ai-response',
  templateUrl: './ai-response.component.html',
  styleUrls: ['./ai-response.component.css']
})
export class AiResponseComponent implements OnInit  {

  constructor() { }
  @Input() questions:any;
  @Output() public enableFeedback = new EventEmitter();
  showResponse:boolean = false;
  showLoader:boolean = true;

  ngOnInit(): void {
    console.log(this.questions)
    this.getResponse();
  }

  getResponse(){
    setTimeout(()=>{
      this.showLoader = false;
      this.showResponse = true;
      this.enableFeedback.emit(true);
    },5000)
  }

}
