import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TextAreaComponent } from './text-area/text-area.component';
import { ToolTipComponent } from './tool-tip/tool-tip.component';
import { TitleDescriptionComponent } from '../shared/title-description/title-description.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { AiResponseComponent } from './ai-response/ai-response.component'

@NgModule({
  declarations: [
    TextAreaComponent,
    ToolTipComponent,
    TitleDescriptionComponent,
    FeedbackComponent,
    AiResponseComponent

  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    TextAreaComponent,
    ToolTipComponent,
    TitleDescriptionComponent,
    FeedbackComponent,
    AiResponseComponent
  ],
  providers: [

  ]
})
export class SharedModule { }
