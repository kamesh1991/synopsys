import { Component } from '@angular/core';

@Component({
  selector: 'tool-tip',
  templateUrl: './tool-tip.component.html',
  styleUrls: ['./tool-tip.component.css']
})
export class ToolTipComponent {

}
