export class stringConstant {

    subHeader: string = 'SYNOPSYS AI KNOWLEDGE ASSISTANT';
    subHeaderDisrciption: string = 'At this time answers are limited to PrimeSim and IC Validator.';
    placeholder : string = 'Ask me a Question, or describe an issue';
    refineLable : string = 'Refine Your Question';
    refinePlaceholder : string = 'Add more context or details to your original question';

}