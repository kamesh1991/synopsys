import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap, timeout } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ApiEndPoints } from 'src/app/shared/ApiEndpoints';

@Injectable({
    providedIn: 'root'
})
export class RestService {

    constructor(private http: HttpClient, private router: Router) { }
    baseUrl: string = environment.baseUrl;
    tokenUrl : string = ApiEndPoints.tokenUrl
    //POST Method
    postData(url: string, postData: any): Observable<any> {
      return this.http.post<any>(this.baseUrl + url, postData).pipe(
          tap(responseData => {
              //console.log(`added record`)
          }),
          catchError(this.handleError(`Error path : ${url}`, []))
      );
    }

    //New Token
    newToken(tokenData: any): Observable<any> {
        return this.http.post<any>(this.baseUrl + this.tokenUrl, tokenData).pipe(
            tap(responseData => {
                console.log(responseData,"token res")
            }),
            catchError(this.handleError(`Error path : ${this.tokenUrl}`, []))
        );
      }

    handleError<T>(operation:any, result?: T) {
        return (error: any): Observable<any> => {
            console.log(error)
            return of(false);
        };
    }
}
