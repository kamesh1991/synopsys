import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RestService } from './rest.service';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

describe('RestService (with spies)', () => {
  // #docregion test-with-spies
  let httpClientSpy: jasmine.SpyObj<HttpClient>;
  let restService: RestService;
  let router: Router;

  beforeEach(() => {
    // TODO: spy on other methods too
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    restService = new RestService(httpClientSpy, router);
  });

});

describe('RestService (with mocks)', () => {
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let restService: RestService;

  const baseURL = environment.baseUrl;

  beforeEach(() => {
    TestBed.configureTestingModule({
      // Import the HttpClient mocking services
      imports: [HttpClientTestingModule],
      // Provide the service-under-test
      providers: [RestService,
        {provide: Router}]
    });

    // Inject the http, test controller, and service-under-test
    // as they will be referenced by each test.
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
    restService = TestBed.inject(RestService);
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });

  describe('#postdata', () => {
    const expectedDatas = [];

    // Expecting the query form of URL so should not 404 when id not found
    const makeUrl = (id: number) => `${baseURL}test`;

    beforeEach(() => {
      spyOn(console, 'log');
    });

    it('should update a data and return it', () => {

      const postData = { id: 1, name: 'A' };
      restService.postData('test', postData).subscribe({
        next: data => expect(data)
          .withContext('should return the data')
          .toEqual(postData),
        error: fail
      });

      // RestService should have made one request to POST data
      const req = httpTestingController.expectOne(`${baseURL}test`);
      expect(req.request.method).toEqual('POST');
      expect(req.request.body).toEqual(postData);

      // Expect server to return the data after POST
      const expectedResponse = new HttpResponse(
        { status: 200, statusText: 'OK', body: postData });
      req.event(expectedResponse);
    });

    it('should turn 404 error into user-facing error', () => {
      const msg = 'Deliberate 404';
      const postData = { id: 1, name: 'A' };
      restService.postData('test', postData).subscribe({
        next: datas => {
          expect(console.log).toHaveBeenCalled();
        },
        error: fail
      });

      const req = httpTestingController.expectOne(`${baseURL}test`);

      // respond with a 404 and the error message in the body
      req.flush(msg, { status: 404, statusText: 'Not Found' });
    });
  });

});
